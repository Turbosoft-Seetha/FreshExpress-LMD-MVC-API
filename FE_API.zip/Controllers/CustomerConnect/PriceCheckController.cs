﻿using Microsoft.AspNetCore.Mvc;
using MVC_API.Models;
using MVC_API.Models.CustomerConnectHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using HttpPostAttribute = Microsoft.AspNetCore.Mvc.HttpPostAttribute;

namespace MVC_API.Controllers.CustomerConnect
{

    public class PriceCheckController : Controller
    {
        DataModel dm = new DataModel();
        string JSONString = string.Empty;

        [HttpPost]


        public string SelCustomerPriceCheck([FromForm] selPriceCheckCustomerIn inputParams)
        {
            dm.TraceService("SelCustomerPriceCheck STARTED -" + DateTime.Now);
            dm.TraceService("====================");

            try
            {
                string salePersonID = inputParams.SalesPersonID == null ? "0" : inputParams.SalesPersonID;

                DataTable dtcus = dm.loadList("SelCustomerPriceCheck", "sp_CustomerConnect", salePersonID.ToString());

                if (dtcus.Rows.Count > 0)
                {
                    List<selPriceCheckCustomerOut> listItems = new List<selPriceCheckCustomerOut>();
                    foreach (DataRow dr in dtcus.Rows)
                    {

                        listItems.Add(new selPriceCheckCustomerOut
                        {
                            cus_ID = dr["cus_ID"].ToString(),
                            cus_Code = dr["cus_Code"].ToString(),
                            cus_Name = dr["cus_Name"].ToString()



                        });
                    }

                    string JSONString = JsonConvert.SerializeObject(new
                    {
                        result = listItems
                    });

                    return JSONString;
                }
                else
                {
                    JSONString = "NoDataRes";
                }
            }
            catch (Exception ex)
            {
                JSONString = "NoDataSQL - " + ex.Message.ToString();
                dm.TraceService(" SelCustomerPriceCheck Exception - " + ex.Message.ToString());
            }
            dm.TraceService("SelCustomerPriceCheck ENDED - " + DateTime.Now);
            dm.TraceService("==================");


            return JSONString;
        }
        public string SelPriceCheck([FromForm] selPriceCheckIn inputParams)
        {
            dm.TraceService("SelPriceCheck STARTED -" + DateTime.Now);
            dm.TraceService("====================");

            try
            {
                string salePersonID = inputParams.SalesPersonID == null ? "0" : inputParams.SalesPersonID;
                string cusID = inputParams.cusID == null ? "0" : inputParams.cusID;
                string[] ar = { cusID.ToString() };
                DataTable dtpriceCheck = dm.loadList("SelPriceCheck", "sp_CustomerConnect", salePersonID.ToString(),ar);

                if (dtpriceCheck.Rows.Count > 0)
                {
                    List<selPriceCheckOut> listItems = new List<selPriceCheckOut>();
                    foreach (DataRow dr in dtpriceCheck.Rows)
                    {

                        listItems.Add(new selPriceCheckOut
                        {
                            prd_ID = dr["prd_ID"].ToString(),
                            prd_Code = dr["prd_Code"].ToString(),
                            prd_Name = dr["prd_Name"].ToString(),
                            uom_ID = dr["uom_ID"].ToString(),
                            uom_Name = dr["uom_Name"].ToString(),
                            Price = dr["pru_Price"].ToString()


                        });
                    }

                    string JSONString = JsonConvert.SerializeObject(new
                    {
                        result = listItems
                    });

                    return JSONString;
                }
                else
                {
                    JSONString = "NoDataRes";
                }
            }
            catch (Exception ex)
            {
                JSONString = "NoDataSQL - " + ex.Message.ToString();
                dm.TraceService(" SelCustomerPriceCheck Exception - " + ex.Message.ToString());
            }
            dm.TraceService("SelCustomerPriceCheck ENDED - " + DateTime.Now);
            dm.TraceService("==================");


            return JSONString;
        }

    }
}